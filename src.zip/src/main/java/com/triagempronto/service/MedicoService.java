package com.triagempronto.service;

import org.springframework.stereotype.Service;
import com.triagempronto.model.Medico;
import com.triagempronto.repository.MedicoRepository;

import java.util.List;

@Service
public class MedicoService {

    private final MedicoRepository medicoRepository;

    public MedicoService(MedicoRepository medicoRepository) {
        this.medicoRepository = medicoRepository;
    }

    public Medico cadastrarMedico(Medico medico) {
        medico.setEmPlantao(false);
        return medicoRepository.save(medico);
    }

    public Medico atualizarPlantao(Long id, boolean emPlantao) {
        return medicoRepository.findById(id)
                .map(medico -> {
                    medico.setEmPlantao(emPlantao);
                    return medicoRepository.save(medico);
                }).orElse(null);
    }

    public List<Medico> medicosEmPlantao() {
        return medicoRepository.findByEmPlantaoTrue();
    }
}

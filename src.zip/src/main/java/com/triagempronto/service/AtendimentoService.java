package com.triagempronto.service;

import org.springframework.stereotype.Service;
import com.triagempronto.model.Paciente;
import com.triagempronto.model.Medico;
import com.triagempronto.enums.Prioridade;
import com.triagempronto.enums.Gravidade;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AtendimentoService {

    private final TriagemService triagemService;
    private final MedicoService medicoService;

    public AtendimentoService(TriagemService triagemService, MedicoService medicoService) {
        this.triagemService = triagemService;
        this.medicoService = medicoService;
    }

    public Paciente proximoPaciente() {
        List<Medico> medicosPlantao = medicoService.medicosEmPlantao();
        if (medicosPlantao.isEmpty()) {
            return null; // Nenhum médico disponível
        }

        List<Paciente> pacientes = triagemService.listarTodos();

        // Ordena pela prioridade e gravidade
        List<Paciente> ordenados = pacientes.stream()
            .sorted(Comparator.comparing(Paciente::getPrioridade, 
                    Comparator.comparingInt(p -> prioridadeToOrdem(p)))
                .thenComparing(p -> gravidadeToOrdem(p.getGravidade())))
            .collect(Collectors.toList());

        if (ordenados.isEmpty()) {
            return null;
        }

        return ordenados.get(0);
    }

    private int prioridadeToOrdem(Paciente p) {
        switch (p.getPrioridade()) {
            case VERMELHA: return 1;
            case AMARELA: return 2;
            case VERDE: return 3;
            default: return 4;
        }
    }

    private int gravidadeToOrdem(Gravidade g) {
        switch (g) {
            case GRAVE: return 1;
            case MODERADA: return 2;
            case LEVE: return 3;
            default: return 4;
        }
    }
}

package com.triagempronto.service;

import org.springframework.stereotype.Service;
import com.triagempronto.model.Paciente;
import com.triagempronto.repository.PacienteRepository;

@Service
public class TriagemService {

    private final PacienteRepository pacienteRepository;

    public TriagemService(PacienteRepository pacienteRepository) {
        this.pacienteRepository = pacienteRepository;
    }

    public Paciente registrarPaciente(Paciente paciente) {
        return pacienteRepository.save(paciente);
    }

    public Paciente buscarPorId(Long id) {
        return pacienteRepository.findById(id).orElse(null);
    }

    public java.util.List<Paciente> listarTodos() {
        return pacienteRepository.findAll();
    }
}

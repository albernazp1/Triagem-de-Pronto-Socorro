package com.triagempronto.enums;

public enum Gravidade {
    LEVE,
    MODERADA,
    GRAVE
}

package com.triagempronto.enums;

public enum Prioridade {
    VERMELHA,
    AMARELA,
    VERDE
}

package com.triagempronto.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.triagempronto.model.Paciente;
import org.springframework.stereotype.Repository;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Long> {
}

package com.triagempronto.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.triagempronto.model.Medico;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MedicoRepository extends JpaRepository<Medico, Long> {
    List<Medico> findByEmPlantaoTrue();
}

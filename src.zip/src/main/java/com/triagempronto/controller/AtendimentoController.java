package com.triagempronto.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.triagempronto.model.Paciente;
import com.triagempronto.service.AtendimentoService;

@RestController
@RequestMapping("/atendimento")
public class AtendimentoController {

    private final AtendimentoService atendimentoService;

    public AtendimentoController(AtendimentoService atendimentoService) {
        this.atendimentoService = atendimentoService;
    }

    @GetMapping("/proximo")
    public ResponseEntity<Paciente> proximoPaciente() {
        Paciente paciente = atendimentoService.proximoPaciente();
        if (paciente == null) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(paciente);
    }
}

package com.triagempronto.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.triagempronto.model.Medico;
import com.triagempronto.service.MedicoService;

@RestController
@RequestMapping("/medicos")
public class MedicoController {

    private final MedicoService medicoService;

    public MedicoController(MedicoService medicoService) {
        this.medicoService = medicoService;
    }

    @PostMapping
    public ResponseEntity<Medico> cadastrarMedico(@RequestBody Medico medico) {
        Medico salvo = medicoService.cadastrarMedico(medico);
        return ResponseEntity.ok(salvo);
    }

    @PutMapping("/{id}/plantao")
    public ResponseEntity<Medico> atualizarPlantao(@PathVariable Long id, @RequestParam boolean emPlantao) {
        Medico atualizado = medicoService.atualizarPlantao(id, emPlantao);
        if (atualizado == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(atualizado);
    }
}
